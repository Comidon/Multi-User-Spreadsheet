﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using SS;
using SpreadsheetUtilities;
using NetworkController;
using System.Net.Sockets;
using System.Threading;
using System.Timers;
using System.Diagnostics;

namespace SpreadsheetGUI
{
    /// <summary>
    /// A class to handle user control and to display the view
    /// </summary>
    public partial class Form1 : Form
    {
        private Socket theServer;
        private bool waitJoin = true;
        private List<string> _items = new List<string>();
        private List<string> _userID = new List<string>();
        private string whatIFocus;
        private static Stopwatch stopWatch = new Stopwatch();
        private static Stopwatch stopWatch2 = new Stopwatch();
        private int failedPing;

        // A sheet to store the backgroud logic.
        private Spreadsheet underLyingSheet;
        char[] separator = new char[] { (char)3 };
        char[] separator2 = new char[] { ' ', '\n' };

        /// <summary>
        /// constructor use to initialize the GUI
        /// </summary>
        public Form1()
        {
            InitializeComponent();
            failedPing = 0;
            // initialize the sheet
            underLyingSheet = new Spreadsheet
                                (s => Regex.IsMatch(s, @"^[a-zA-Z][1-9][0-9]?$"), s => s.ToUpper(), "ps6");


            stopWatch = new Stopwatch();
            stopWatch.Start();
            stopWatch2 = new Stopwatch();
            stopWatch2.Start();
            // handler used to update current selected cell information
            spreadsheetPanel1.SelectionChanged += updateCellMessage;
            foreach (Control control in this.Controls)
            {
                control.PreviewKeyDown += new PreviewKeyDownEventHandler(control_PreviewKeyDown);
            }
            foreach (Control control in spreadsheetPanel1.Controls)
            {
                control.PreviewKeyDown += new PreviewKeyDownEventHandler(control_PreviewKeyDown);
            }
            textBox1.Text = "A1";
            Join.Enabled = false;
            textBox4.ReadOnly = true;
        }

        void control_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (e.KeyCode == Keys.Up || e.KeyCode == Keys.Down || e.KeyCode == Keys.Left || e.KeyCode == Keys.Right|| e.KeyCode == Keys.Enter)
            {
                e.IsInputKey = true;
                int col;
                int row;
                spreadsheetPanel1.GetSelection(out col, out row);

                switch (e.KeyCode)
                {
                    case Keys.Enter:
                        TextBox tbx = this.Controls.Find("txt", true).FirstOrDefault() as TextBox;
                        if (tbx != null)
                        {
                            Networking.Send(theServer, "unfocus" + " " + whatIFocus + (char)3);
                            whatIFocus = "";
                            spreadsheetPanel1.Focus();
                            Controls.Remove(tbx);
                        }
                        else
                        {
                            spreadsheetPanel1.GetSelection(out col, out row);
                            string cellname = GetNameOnSelect();
                            TextBox txt = new TextBox();
                            txt.Name = "txt";
                            txt.Text = textBox3.Text;
                            txt.Width = 80;
                            txt.Height = 20;
                            txt.KeyDown += new KeyEventHandler(txtKeyDown);
                            txt.Location = new Point(31 + (col - spreadsheetPanel1.drawingPanel._firstColumn) * 80, 81 + (row - spreadsheetPanel1.drawingPanel._firstRow) * 20);
                            this.Controls.Add(txt);
                            txt.BringToFront();
                            txt.Focus();
                            whatIFocus = cellname;
                            Networking.Send(theServer, "focus" + " " + cellname + (char)3);
                        }
                        break;
                    case Keys.Up:
                        spreadsheetPanel1.SetSelection(col, row - 1);
                        break;
                    case Keys.Down:
                        spreadsheetPanel1.SetSelection(col, row + 1);
                        break;
                    case Keys.Left:
                        spreadsheetPanel1.SetSelection(col - 1, row);
                        break;
                    case Keys.Right:
                        spreadsheetPanel1.SetSelection(col + 1, row);
                        break;

                }

                updateCellMessage(spreadsheetPanel1);

            }
        }
        
        private void Connect_Click(object sender, EventArgs e)
        {
            if (textBox5.Text == "")
            {
                MessageBox.Show("Please enter a server address");
                return;
            }
            
            try
            {
                theServer = Networking.ConnectToServer(FirstContact, textBox5.Text);

            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }


        }

        private void FirstContact(SocketState state)
        {
            byte[] messageBytes = Encoding.UTF8.GetBytes("register" + (char)3);
            theServer.Send(messageBytes, messageBytes.Length, SocketFlags.None);
            

            state.callMe = ChoosingSpreadsheet;
            Networking.GetData(state);
        }

        private void ChoosingSpreadsheet(SocketState state)
        {
            string totalData = state.sb.ToString();
            if (totalData.Contains((char)3))
            {
              string[] parts = totalData.Split(separator, StringSplitOptions.RemoveEmptyEntries);
              string[] data = parts[0].Split(separator2, StringSplitOptions.RemoveEmptyEntries);

              if (data[0] != "connect_accepted")
              {
                  throw new Exception("Incorrect server");
              }
              
              data = data.Skip(1).ToArray();
              _items = data.ToList();
              state.sb.Remove(0, parts[0].Length+1);
              Invoke(new MethodInvoker(() => UpdateListBox()));

              LoadingSpreadSheet(state);
            }
            else
            {
               state.callMe = ChoosingSpreadsheet;
               Networking.GetData(state);
            }

        }

        private void UpdateListBox()
        {
            Join.Enabled = true;
            textBox4.ReadOnly = false;
            if (_items.Count == 0)
            {
                _items.Add( "No Existing Spreadsheet");
                textBox4.Text = "NewSpreadSheet";
            }
            listBox1.DataSource = _items;
            textBox5.ReadOnly = true;
            Connect.Enabled = false;

        }

        private void LoadingSpreadSheet(SocketState state)
        {
            while (textBox4.Text == "" || waitJoin)
            {
                
            }

            byte[] messageBytes = Encoding.UTF8.GetBytes("load" + " " + textBox4.Text + (char)3);
            Invoke(new MethodInvoker(() => AfterLoading()));
            theServer.Send(messageBytes, messageBytes.Length, SocketFlags.None);
            state.callMe = ReceiveFullState;
            Networking.GetData(state);

        }

        private void AfterLoading()
        {
            Join.Enabled = false;
            textBox4.ReadOnly = true;
        }

        private void ReceiveFullState(SocketState state)
        {
            string totalData  = state.sb.ToString();
            if (totalData.Contains((char)3))
            {
                string[] parts = totalData.Split(separator, StringSplitOptions.RemoveEmptyEntries);
                string[] data = parts[0].Split(separator2, StringSplitOptions.RemoveEmptyEntries);


                if (data[0] == "file_load_error")
                {
                    MessageBox.Show("file_load_error");
                }
                else if (data[0] == "full_state")
                {
                    data = data.Skip(1).ToArray();
                    foreach (string x in data)
                    {
                        string[] subx = x.Split(new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries);
                        String cellName = subx[0];
                        String cellContent = "";
                        if (subx.Length > 1)
                        {
                            cellContent = subx[1];
                        }

                        try
                        {
                            underLyingSheet.SetContentsOfCell(cellName, cellContent);
                            
                            Invoke((Action)delegate () { updateCellMessage(spreadsheetPanel1); });
                            Invoke((Action)delegate () { UpdateAfter(cellName); });
                        }

                        // display circular dependecy error message
                        catch (CircularException)
                        {
                            MessageBox.Show("Error: circular dependecy");
                        }

                        // display invalid formula error message
                        catch (FormulaFormatException)
                        {
                            MessageBox.Show("Error: invalid formula format");
                        }

                        // something shouldn't happen
                        catch (Exception)
                        {
                            MessageBox.Show("Error: unexpected error");
                        }

                    }
                    _items = data.ToList();
                    state.sb.Remove(0, parts[0].Length + 1);
                }
                else
                {
                    MessageBox.Show("Unknown Error When Loading Full State");
                }

                Invoke(new MethodInvoker(() => Ping()));
                Invoke(new MethodInvoker(() => PingResponse()));
                Invoke(new MethodInvoker(() => FinalStepBeforeReceiveData()));
                state.callMe = ReceiveData;
                Networking.GetData(state);
            }
            else
            {
                state.callMe = ReceiveFullState;
                Networking.GetData(state);
            }
            
        }
        private void UpdateAfter(string cell)
        {
            string value = underLyingSheet.GetCellValue(cell).ToString();
            char[] x = cell.ToCharArray();
            int col = char.ToUpper(cell[0]) - 65;
            string t = cell.Substring(1);
            int row = int.Parse(t) - 1;
            spreadsheetPanel1.SetValue(col,row,value);
        }

        private void FinalStepBeforeReceiveData()
        {
            label5.Text = "CellsEditedByUsers";
            _items.Clear();
            listBox1.DataSource = null;
        }

        private void ReceiveData(SocketState state)
        {
            string totalData = state.sb.ToString();
            if (totalData.Contains((char)3))
            {
                string[] parts = totalData.Split(separator, StringSplitOptions.RemoveEmptyEntries);
                string[] data = parts[0].Split(separator2, StringSplitOptions.RemoveEmptyEntries);

                if (data[0] == "focus")
                {
                    data = data.Skip(1).ToArray();
                    string[] subx = data[0].Split(new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries);
                    string cellName = subx[0];
                    string userID = subx[1];

                    _items.Add(cellName);
                    _userID.Add(userID);
                    Invoke(new MethodInvoker(() => ListBoxUpdate()));

                }
                else if (data[0] == "unfocus")
                {
                    data = data.Skip(1).ToArray();
                    string userID = data[0];

                    int index = _userID.IndexOf(userID);
                    _userID.RemoveAt(index);
                    _items.RemoveAt(index);
                    Invoke(new MethodInvoker(() => ListBoxUpdate()));
                }
                else if (data[0] == "change")
                {

                    data = data.Skip(1).ToArray();
                    foreach (string x in data)
                    {
                        string[] subx = x.Split(new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries);
                        String cellName = subx[0];
                        String cellContent = "";
                        if (subx.Length > 1)
                        {
                            cellContent = subx[1];
                        }

                        try
                        {
                            underLyingSheet.SetContentsOfCell(cellName, cellContent);
                            Invoke((Action)delegate () { updateCellMessage(spreadsheetPanel1); });
                            Invoke((Action)delegate () { UpdateAfter(cellName); });
                        }

                        // display circular dependecy error message
                        catch (CircularException)
                        {
                            MessageBox.Show("Error: circular dependecy");
                        }

                        // display invalid formula error message
                        catch (FormulaFormatException)
                        {
                            MessageBox.Show("Error: invalid formula format");
                        }

                        // something shouldn't happen
                        catch (Exception)
                        {
                            MessageBox.Show("Error: unexpected error");
                        }

                    }

                }
                else if (data[0] == "disconnect")
                {
                    MessageBox.Show("Disconnected from server");
                }
                else if (data[0] == "ping")
                {
                    Networking.Send(theServer, "ping_response" + " " + (char)3);
                }
                else if (data[0] == "ping_response")
                {
                    failedPing = 0;
                }
                else
                {

                }

                state.sb.Remove(0, parts[0].Length + 1);
                state.callMe = ReceiveData;
                Networking.GetData(state);
            }
            else
            {
                state.callMe = ReceiveData;
                Networking.GetData(state);
            }
 
        }
        private void ListBoxUpdate()
        {
            listBox1.DataSource = null;
            listBox1.DataSource = _items;
            listBox1.Update();
        }

        private void Ping()
        {
            Thread t = new Thread(() => PingHandler());
            t.Start();
        }
        private void PingHandler()
        {
            while (theServer != null)
            {
                if (stopWatch.IsRunning)
                {
                    while (stopWatch.Elapsed.Seconds < 10)
                    {
                    }
                    Networking.Send(theServer, "ping" + " " + (char)3);
                    stopWatch.Reset();
                }
                else
                {
                    stopWatch.Start();
                }
            }
        }

        private void PingResponse()
        {
            Thread t = new Thread(() => PingResponseHandler());
            t.Start();
        }
        private void PingResponseHandler()
        {
            while (theServer != null)
            {
                if (stopWatch2.IsRunning)
                {
                    while (stopWatch2.Elapsed.Seconds < 10)
                    {

                    }
                    failedPing += 1;
                    if (failedPing >= 6)
                    {
                        Networking.Send(theServer, "disconnect" + " " + (char)3);
                        MessageBox.Show("Disconnected from server");
                        Invoke(new MethodInvoker(() => CloseForm()));
                    }
                    stopWatch2.Reset();
                }
                else
                {
                    stopWatch2.Start();
                }

            }
        }

        private void CloseForm()
        {
            theServer = null;
            Close();
        }

        /// <summary>
        /// A helper method used to update the information 
        /// in the top three text boxs.
        /// </summary>
        /// <param name="ss"></param>
        private void updateCellMessage(SpreadsheetPanel ss)
        {
            // let the left box display the cell name
            String cellName = GetNameOnSelect();
            textBox1.Text = cellName;
            
            // let the right box display the content
            Object cellContent = underLyingSheet.GetCellContents(cellName);
            if (cellContent is Formula)
            {
                textBox3.Text = "=" + cellContent.ToString();
            }
            else
            {
                textBox3.Text = cellContent.ToString();
            }

            // let the right box display the value
            Object cellValue = underLyingSheet.GetCellValue(cellName);
            textBox2.Text = cellValue.ToString();

            

        }

        /// <summary>
        /// A helper method used to get the cell name of the current selection
        /// on the spreadsheet.
        /// </summary>
        /// <returns></returns>
        private string GetNameOnSelect()
        {
            int col;
            int row;    
            
            // Get the location of the current selection
            spreadsheetPanel1.GetSelection(out col, out row);

            // Covert the location to a cell name
            row++;
            char Col = (char)('A' + col);

            return "" + Col + row;
        }


        private void txtKeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                TextBox tbx = this.Controls.Find("txt", true).FirstOrDefault() as TextBox;

                String cellName = GetNameOnSelect();
                String OriginalContent = underLyingSheet.GetCellContents(cellName).ToString();
                String cellContent = tbx.Text;
                
                // set content and do evaluation of the selected cell
                try
                {
                    underLyingSheet.SetContentsOfCell(cellName, cellContent);
                }

                // display circular dependecy error message
                catch (CircularException)
                {
                    MessageBox.Show("Error: circular dependecy");
                }

                // display invalid formula error message
                catch (FormulaFormatException)
                {
                    MessageBox.Show("Error: invalid formula format");
                }

                // something shouldn't happen
                catch (Exception)
                {
                    MessageBox.Show("Error: unexpected error");
                }

                if (underLyingSheet.GetCellContents(cellName).ToString() == cellContent)
                {
                    underLyingSheet.SetContentsOfCell(cellName, OriginalContent);
                }

                Networking.Send(theServer, "edit" + " " + cellName + ":" + cellContent + (char)3);
                Networking.Send(theServer, "unfocus" + " " + cellName + (char)3);
                spreadsheetPanel1.Focus();
                Controls.Remove(tbx);
                    
            }
        }

        private void revertToolStripMenuItem_Click(object sender, EventArgs e)
        {
            String cellName = GetNameOnSelect();
            Networking.Send(theServer, "revert" + " " + cellName + (char)3);
        }



        private void Join_Click(object sender, EventArgs e)
        {
            waitJoin = false;
        }

        /// <summary>
        /// Method used to detect an "Click" input, 
        /// if an "Click" is catched on "close strip", 
        /// first determine wether to save, 
        /// then close the form.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Networking.Send(theServer, "disconnect" + " " + (char)3);
            theServer = null;
            Close();
        }

        private void redoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Networking.Send(theServer, "undo" + (char)3);
        }

        /// <summary>
        /// Override the OnFormClosing such that when clicking the close button
        /// in the corner, it will ask to save.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
           
            Networking.Send(theServer, "disconnect" + " " + (char)3);
            theServer = null;
            Close();

        }

        /// <summary>
        /// Method to display help information.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Use mouse or arrow keys for selecting cells. \n" +
                            "Press Enter key to edit celss \n" +
                            "Press Enter Again to close edit text box \n" +
                            "Clicking on Action button for Revert or Undo actions on the current selected cell\n" +
                            "The result will be sent to server.");
        }

        private void listBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            if (!textBox4.ReadOnly)
            {
                textBox4.Text = _items[listBox1.SelectedIndex];
            }
        }
    }
}
