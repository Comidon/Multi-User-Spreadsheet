﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using SS;
using SpreadsheetUtilities;
using NetworkController;
using System.Net.Sockets;
using System.Threading;
using System.Timers;
using System.Diagnostics;

namespace SpreadsheetGUI
{
    /// <summary>
    /// A class to handle user control and to display the view.
    /// </summary>
    public partial class Form1 : Form
    {
        // A sheet to store the backgroud logic.
        private Spreadsheet underLyingSheet;

        //Socket for the spreadsheet server
        private Socket theServer;

        //Boolean used for detecting whether it need to join a spreadsheet or not
        private bool waitJoin = true;

        //Record for displaying the current cell which is being edited by users
        private List<string> _items = new List<string>();     
        private List<string> _userID = new List<string>();

        //Record cell name for sending focus and unfocus messages
        private string whatIFocus;                       
        
        //One stopwatch for PingLoop, another for PingResponseLoop
        private static Stopwatch stopWatch = new Stopwatch();
        private static Stopwatch stopWatch2 = new Stopwatch();
        //Record amount of failed ping
        private int failedPing;

        //Two main kinds of separator that will be used in parsing message
        char[] separator = new char[] { (char)3 };
        char[] separator2 = new char[] { ' ', '\n' };

        /// <summary>
        /// Constructor use to initialize the GUI.
        /// </summary>
        public Form1()
        {
            InitializeComponent();
            
            // initialize the sheet
            underLyingSheet = new Spreadsheet
                                (s => Regex.IsMatch(s, @"^[a-zA-Z][1-9][0-9]?$"), s => s.ToUpper(), "ps6");
            
            // handler used to update current selected cell information
            spreadsheetPanel1.SelectionChanged += updateCellMessage;

            //Add control for the pop-up textbox above spreadsheet panel
            foreach (Control control in this.Controls)
            {
                control.PreviewKeyDown += new PreviewKeyDownEventHandler(control_PreviewKeyDown);
            }
            foreach (Control control in spreadsheetPanel1.Controls)
            {
                control.PreviewKeyDown += new PreviewKeyDownEventHandler(control_PreviewKeyDown);
            }

            //Start two stopwatch 
            stopWatch = new Stopwatch();
            stopWatch.Start();
            stopWatch2 = new Stopwatch();
            stopWatch2.Start();
            
            //Initialize the failedPing to be 0
            failedPing = 0;

            //Initialize the textbox for displaying current selected cell's name
            textBox1.Text = "A1";

            //Disable the Join spreadsheet button before the connection is established
            Join.Enabled = false;
            textBox4.ReadOnly = true;
        }

        /// <summary>
        /// A helper method used to update the information 
        /// in the top three text boxs.
        /// </summary>
        /// <param name="ss"></param>
        private void updateCellMessage(SpreadsheetPanel ss)
        {
            // let the left box display the cell name
            String cellName = GetNameOnSelect();
            textBox1.Text = cellName;

            // let the right box display the content
            Object cellContent = underLyingSheet.GetCellContents(cellName);
            if (cellContent is Formula)
            {
                textBox3.Text = "=" + cellContent.ToString();
            }
            else
            {
                textBox3.Text = cellContent.ToString();
            }

            // let the right box display the value
            Object cellValue = underLyingSheet.GetCellValue(cellName);
            textBox2.Text = cellValue.ToString();
        }

        /// <summary>
        /// A helper method used to get the cell name of the current selection
        /// on the spreadsheet.
        /// </summary>
        /// <returns></returns>
        private string GetNameOnSelect()
        {
            int col;
            int row;

            // Get the location of the current selection
            spreadsheetPanel1.GetSelection(out col, out row);

            // Covert the location to a cell name
            row++;
            char Col = (char)('A' + col);

            return "" + Col + row;
        }

        /// <summary>
        /// This handler method is for handling:
        /// 
        /// 1.Arrow keys: we want to use arrow keys to select cells.
        /// 
        /// 2.Enter key: we use enter key to instantiate a textbox
        ///              above the current selected cell to achieve
        ///              "Edit cell content in cell".
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void control_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            //Handle all the five keys
            if (e.KeyCode == Keys.Up || e.KeyCode == Keys.Down || e.KeyCode == Keys.Left || e.KeyCode == Keys.Right|| e.KeyCode == Keys.Enter)
            {
                //Some preparation for the following process
                e.IsInputKey = true;
                int col;
                int row;
                spreadsheetPanel1.GetSelection(out col, out row);

                switch (e.KeyCode)
                {
                    case Keys.Enter:
                        TextBox tbx = this.Controls.Find("txt", true).FirstOrDefault() as TextBox;

                        //If there is such a textbox existing, remove it and send unfocus message
                        if (tbx != null)
                        {
                            Networking.Send(theServer, "unfocus" + " " + whatIFocus + (char)3);
                            whatIFocus = "";
                            spreadsheetPanel1.Focus();
                            Controls.Remove(tbx);
                        }
                        //If there is not such a textbox, add a new one above the selected cell
                        //to allow user to edit the cell content and send focus message to server
                        else
                        {
                            spreadsheetPanel1.GetSelection(out col, out row);
                            string cellname = GetNameOnSelect();
                            TextBox txt = new TextBox();
                            txt.Name = "txt";
                            txt.Text = textBox3.Text;
                            txt.Width = 80;
                            txt.Height = 20;
                            txt.KeyDown += new KeyEventHandler(txtKeyDown);
                            txt.Location = new Point(31 + (col - spreadsheetPanel1.drawingPanel._firstColumn) * 80, 81 + (row - spreadsheetPanel1.drawingPanel._firstRow) * 20);
                            this.Controls.Add(txt);
                            txt.BringToFront();
                            txt.Focus();
                            whatIFocus = cellname;
                            Networking.Send(theServer, "focus" + " " + cellname + (char)3);
                        }
                        break;
                    case Keys.Up:
                        spreadsheetPanel1.SetSelection(col, row - 1);
                        break;
                    case Keys.Down:
                        spreadsheetPanel1.SetSelection(col, row + 1);
                        break;
                    case Keys.Left:
                        spreadsheetPanel1.SetSelection(col - 1, row);
                        break;
                    case Keys.Right:
                        spreadsheetPanel1.SetSelection(col + 1, row);
                        break;

                }

                updateCellMessage(spreadsheetPanel1);

            }
        }

        /// <summary>
        /// This method is a handler for closing the pop-up textbox 
        /// After the enter key is detected, this handler will:
        /// 
        /// 1.Try to save the cell content locally to check whether there
        ///   is any error in the new content.
        ///   
        /// 2.Recover the original content.
        /// (If the content of this cell is changed by other user during the editing
        ///  it won't recover the original content).
        ///  
        /// 3.Send the new edited content message to server.
        /// 
        /// 4.Remove the pop-up textbox.
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtKeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                TextBox tbx = this.Controls.Find("txt", true).FirstOrDefault() as TextBox;

                String cellName = GetNameOnSelect();
                String OriginalContent = underLyingSheet.GetCellContents(cellName).ToString();
                String cellContent = tbx.Text;

                // Try set content and do evaluation of the selected cell
                try
                {
                    underLyingSheet.SetContentsOfCell(cellName, cellContent);
                }

                // display circular dependecy error message
                catch (CircularException)
                {
                    MessageBox.Show("Error: circular dependecy");
                }

                // display invalid formula error message
                catch (FormulaFormatException)
                {
                    MessageBox.Show("Error: invalid formula format");
                }

                // something shouldn't happen
                catch (Exception)
                {
                    MessageBox.Show("Error: unexpected error");
                }

                if (underLyingSheet.GetCellContents(cellName).ToString() == cellContent)
                {
                    underLyingSheet.SetContentsOfCell(cellName, OriginalContent);
                }

                Networking.Send(theServer, "edit" + " " + cellName + ":" + cellContent + (char)3);
                Networking.Send(theServer, "unfocus" + " " + cellName + (char)3);
                spreadsheetPanel1.Focus();
                Controls.Remove(tbx);

            }
        }

        /// <summary>
        /// This is the Click event handler for connect button
        /// It will try to connect to the target server.
        /// 
        /// If failed to connect to the target server,
        /// it will show a message box to tell user.
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Connect_Click(object sender, EventArgs e)
        {
            if (textBox5.Text == "")
            {
                MessageBox.Show("Please enter a server address");
                return;
            }
            
            try
            {
                theServer = Networking.ConnectToServer(FirstContact, textBox5.Text);

            }
            catch (Exception)
            {
                MessageBox.Show("Failed to connect to target server");
            }


        }

        /////////////////////////////////////////////////////////////
        //Entering the connection phases
        /////////////////////////////////////////////////////////////

        /// <summary>
        /// First phase of establishing server connection.
        /// 
        /// It will send a register message to server,
        /// change the call back method to the next phase.
        /// 
        /// </summary>
        /// <param name="state"></param>
        private void FirstContact(SocketState state)
        {
            byte[] messageBytes = Encoding.UTF8.GetBytes("register" + (char)3);
            theServer.Send(messageBytes, messageBytes.Length, SocketFlags.None);
            state.callMe = ChoosingSpreadsheet;
            Networking.GetData(state);
        }

        /// <summary>
        /// Second phase of establishing server connection.
        /// 
        /// It will receive the existing spreadsheet list from server
        /// and display them in the winform listbox for user to choose.
        /// 
        /// Then change to the next phase of server connection.
        /// 
        /// </summary>
        /// <param name="state"></param>
        private void ChoosingSpreadsheet(SocketState state)
        {
            string totalData = state.sb.ToString();

            //If didn't receive full accept message from server it will
            //keep trying to get more data
            if (totalData.Contains((char)3))
            {
              string[] parts = totalData.Split(separator, StringSplitOptions.RemoveEmptyEntries);
              string[] data = parts[0].Split(separator2, StringSplitOptions.RemoveEmptyEntries);

              if (data[0] != "connect_accepted")
              {
                    MessageBox.Show("Failed to get spreadsheet list");
              }
              
              data = data.Skip(1).ToArray();
              _items = data.ToList();
              state.sb.Remove(0, parts[0].Length+1);
              Invoke(new MethodInvoker(() => UpdateListBox()));

              //Call the next phase function
              LoadingSpreadSheet(state);
            }
            else
            {
               state.callMe = ChoosingSpreadsheet;
               Networking.GetData(state);
            }

        }

        /// <summary>
        /// A helper method for displaying all existing 
        /// spreadsheet in the server.
        /// 
        /// If there is no existing function, it will mention 
        /// user to create a new one.
        /// 
        /// If will also disable the connect button and 
        /// enable the join button for further phase of server connection.
        /// 
        /// </summary>
        private void UpdateListBox()
        {
            Join.Enabled = true;
            textBox4.ReadOnly = false;
            if (_items.Count == 0)
            {
                _items.Add( "No Existing Spreadsheet");
                textBox4.Text = "NewSpreadSheet";
            }
            listBox1.DataSource = _items;
            textBox5.ReadOnly = true;
            Connect.Enabled = false;

        }

        /// <summary>
        /// A helper method to fire the loading message after 
        /// join button is clicked
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Join_Click(object sender, EventArgs e)
        {
            waitJoin = false;
        }

        /// <summary>
        /// Third phase of establishing server connection.
        /// 
        /// It will send load spreadsheet message to server and 
        /// change to the next phase of server connection.
        /// 
        /// </summary>
        /// <param name="state"></param>
        private void LoadingSpreadSheet(SocketState state)
        {
            while (textBox4.Text == "" || waitJoin)
            {
                
            }

            byte[] messageBytes = Encoding.UTF8.GetBytes("load" + " " + textBox4.Text + (char)3);
            Invoke(new MethodInvoker(() => AfterLoading()));
            theServer.Send(messageBytes, messageBytes.Length, SocketFlags.None);
            state.callMe = ReceiveFullState;
            Networking.GetData(state);

        }

        /// <summary>
        /// A helper method used for disabling the join button
        /// after the join message is sent.
        /// </summary>
        private void AfterLoading()
        {
            Join.Enabled = false;
            textBox4.ReadOnly = true;
        }

        /// <summary>
        /// Fourth phase of establishing server connection.
        /// 
        /// Waiting for receiving the full load message from server
        /// and use them to update local spreadsheet.
        /// (Show message to tell user file load error if receive such message)
        /// 
        /// Then involk the two ping loop handler functions
        /// and switch to next phase of server connection.
        /// 
        /// </summary>
        /// <param name="state"></param>
        private void ReceiveFullState(SocketState state)
        {
            string totalData  = state.sb.ToString();
            if (totalData.Contains((char)3))
            {
                string[] parts = totalData.Split(separator, StringSplitOptions.RemoveEmptyEntries);
                string[] data = parts[0].Split(separator2, StringSplitOptions.RemoveEmptyEntries);


                if (data[0] == "file_load_error")
                {
                    MessageBox.Show("file_load_error");
                }
                else if (data[0] == "full_state")
                {
                    data = data.Skip(1).ToArray();
                    foreach (string x in data)
                    {
                        string[] subx = x.Split(new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries);
                        String cellName = subx[0];
                        String cellContent = "";
                        if (subx.Length > 1)
                        {
                            cellContent = subx[1];
                        }

                        try
                        {
                            underLyingSheet.SetContentsOfCell(cellName, cellContent);

                            //Update the cell to let the new value displayed in cell immediately
                            Invoke((Action)delegate () { updateCellMessage(spreadsheetPanel1); });
                            Invoke((Action)delegate () { UpdateAfter(cellName); });
                        }

                        // display circular dependecy error message
                        catch (CircularException)
                        {
                            MessageBox.Show("Error: circular dependecy");
                        }

                        // display invalid formula error message
                        catch (FormulaFormatException)
                        {
                            MessageBox.Show("Error: invalid formula format");
                        }

                        // something shouldn't happen
                        catch (Exception)
                        {
                            MessageBox.Show("Error: unexpected error");
                        }

                    }
                    _items = data.ToList();
                    state.sb.Remove(0, parts[0].Length + 1);
                }
                else
                {
                    MessageBox.Show("Unknown Error When Loading Full State");
                }

                Invoke(new MethodInvoker(() => Ping()));
                Invoke(new MethodInvoker(() => PingResponse()));
                Invoke(new MethodInvoker(() => FinalStepBeforeReceiveData()));
                state.callMe = ReceiveData;
                Networking.GetData(state);
            }
            else
            {
                state.callMe = ReceiveFullState;
                Networking.GetData(state);
            }
            
        }

        /// <summary>
        /// A helper method used for displaying the new value of cell immediately.
        /// </summary>
        /// <param name="cell"></param>
        private void UpdateAfter(string cell)
        {
            string value = underLyingSheet.GetCellValue(cell).ToString();
            char[] x = cell.ToCharArray();
            int col = char.ToUpper(cell[0]) - 65;
            string t = cell.Substring(1);
            int row = int.Parse(t) - 1;
            spreadsheetPanel1.SetValue(col,row,value);
        }

        /// <summary>
        /// The final helper method before entering the formal 
        /// data receiving and processing loop.
        /// 
        /// It will change the label text from "SpreadsheetList"
        /// to "CellsEditedByUsers" and clear the listbox data source,
        /// since we will use this listbox to display the cells
        /// which is being edited by users.
        /// 
        /// </summary>
        private void FinalStepBeforeReceiveData()
        {
            label5.Text = "CellsEditedByUsers";
            _items.Clear();
            listBox1.DataSource = null;
        }

        /// <summary>
        /// A helper method for creating new thread for ping loop function
        /// </summary>
        private void Ping()
        {
            Thread t = new Thread(() => PingHandler());
            t.Start();
        }

        private void PingHandler()
        {
            while (theServer != null)
            {
                if (stopWatch.IsRunning)
                {
                    while (stopWatch.Elapsed.Seconds < 10)
                    {
                    }
                    Networking.Send(theServer, "ping" + " " + (char)3);
                    stopWatch.Reset();
                }
                else
                {
                    stopWatch.Start();
                }
            }
        }

        /// <summary>
        /// A helper method for creating new thread for ping response loop
        /// </summary>
        private void PingResponse()
        {
            Thread t = new Thread(() => PingResponseHandler());
            t.Start();
        }

        private void PingResponseHandler()
        {
            while (theServer != null)
            {
                if (stopWatch2.IsRunning)
                {
                    while (stopWatch2.Elapsed.Seconds < 10)
                    {

                    }
                    failedPing += 1;
                    if (failedPing >= 6)
                    {
                        Networking.Send(theServer, "disconnect" + " " + (char)3);
                        MessageBox.Show("Disconnected from server");
                        Invoke(new MethodInvoker(() => CloseForm()));
                    }
                    stopWatch2.Reset();
                }
                else
                {
                    stopWatch2.Start();
                }

            }
        }

        /// <summary>
        /// A helper method for closing winform in other thread
        /// </summary>
        private void CloseForm()
        {
            theServer = null;
            Close();
        }

        /// <summary>
        /// Final phase of establishing server connection.
        /// 
        /// It is responsible for processing "focus, "unfocus",
        /// "change", "ping", "ping_response" and "disconnect" messages
        /// and igore the invalid messages automatically.
        /// 
        /// Then remove the processed message from string builder 
        /// inside the socketstate object.
        /// 
        /// </summary>
        /// <param name="state"></param>
        private void ReceiveData(SocketState state)
        {
            string totalData = state.sb.ToString();
            if (totalData.Contains((char)3))
            {
                string[] parts = totalData.Split(separator, StringSplitOptions.RemoveEmptyEntries);
                string[] data = parts[0].Split(separator2, StringSplitOptions.RemoveEmptyEntries);

                if (data[0] == "focus")
                {
                    data = data.Skip(1).ToArray();
                    string[] subx = data[0].Split(new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries);
                    string cellName = subx[0];
                    string userID = subx[1];

                    _items.Add(cellName);
                    _userID.Add(userID);
                    Invoke(new MethodInvoker(() => ListBoxUpdate()));

                }
                else if (data[0] == "unfocus")
                {
                    data = data.Skip(1).ToArray();
                    string userID = data[0];

                    int index = _userID.IndexOf(userID);
                    _userID.RemoveAt(index);
                    _items.RemoveAt(index);
                    Invoke(new MethodInvoker(() => ListBoxUpdate()));
                }
                else if (data[0] == "change")
                {

                    data = data.Skip(1).ToArray();
                    foreach (string x in data)
                    {
                        string[] subx = x.Split(new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries);
                        String cellName = subx[0];
                        String cellContent = "";
                        if (subx.Length > 1)
                        {
                            cellContent = subx[1];
                        }

                        try
                        {
                            underLyingSheet.SetContentsOfCell(cellName, cellContent);
                            Invoke((Action)delegate () { updateCellMessage(spreadsheetPanel1); });
                            Invoke((Action)delegate () { UpdateAfter(cellName);});
                        }

                        // display circular dependecy error message
                        catch (CircularException)
                        {
                            MessageBox.Show("Error: circular dependecy");
                        }

                        // display invalid formula error message
                        catch (FormulaFormatException)
                        {
                            MessageBox.Show("Error: invalid formula format");
                        }

                        // something shouldn't happen
                        catch (Exception)
                        {
                            MessageBox.Show("Error: unexpected error");
                        }

                        foreach (string c in underLyingSheet.GetNamesOfAllNonemptyCells())
                        {
                            Invoke((Action)delegate () { UpdateAfter(c);});
                        }
                    }

                }
                else if (data[0] == "disconnect")
                {
                    MessageBox.Show("Disconnected from server");
                }
                else if (data[0] == "ping")
                {
                    Networking.Send(theServer, "ping_response" + " " + (char)3);
                }
                else if (data[0] == "ping_response")
                {
                    failedPing = 0;
                }

                state.sb.Remove(0, parts[0].Length + 1);
                state.callMe = ReceiveData;
                Networking.GetData(state);
            }
            else
            {
                state.callMe = ReceiveData;
                Networking.GetData(state);
            }
 
        }

        /// <summary>
        /// A helper method for updating listbox
        /// </summary>
        private void ListBoxUpdate()
        {
            listBox1.DataSource = null;
            listBox1.DataSource = _items;
            listBox1.Update();
        }

        /////////////////////////////////////////////////////////////
        //End of the connection phases
        /////////////////////////////////////////////////////////////

        /// <summary>
        /// A helper method for updating spreadsheet textbox according to
        /// the selected spreadsheet in listbox.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void listBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            if (!textBox4.ReadOnly)
            {
                textBox4.Text = _items[listBox1.SelectedIndex];
            }
        }

        /// <summary>
        /// Method used to sending revert message to server when the button is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void revertToolStripMenuItem_Click(object sender, EventArgs e)
        {
            String cellName = GetNameOnSelect();
            Networking.Send(theServer, "revert" + " " + cellName + (char)3);
        }

        /// <summary>
        /// Method used to sending undo message to server when the button is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void redoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Networking.Send(theServer, "undo" + (char)3);
        }

        /// <summary>
        /// Method used to close form and send disconnect message to server
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Networking.Send(theServer, "disconnect" + " " + (char)3);
            theServer = null;
            Close();
        }

        /// <summary>
        /// Override the OnFormClosing such that when clicking the close button
        /// in the corner,
        /// </summary>
        /// <param name="e"></param>
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
           
            Networking.Send(theServer, "disconnect" + " " + (char)3);
            theServer = null;
            Close();

        }
        
        /// <summary>
        /// Method to display help information.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Use mouse or arrow keys for selecting cells. \n" +
                            "Press Enter key to edit celss \n" +
                            "Press Enter Again to close edit text box \n" +
                            "Clicking on Action button for Revert or Undo actions on the current selected cell\n" +
                            "The result will be sent to server.");
        }

    }
}
